import re
from .models import FinancialInfo

def process_transcript(file_path, transcript_id):
    try:
        with open(file_path, 'r') as file:
            content = file.read()
    except Exception as e:
        print(f"Error reading file: {e}")
        return {"error": "Error reading file"}

    if not content.strip():
        return {"message": "File content is empty"}

    assets_pattern = re.compile(r'\b(?:asset|assets)\b.*?\.|.*?\b(?:asset|assets)\b.*?\.', re.IGNORECASE)
    expenditures_pattern = re.compile(r'\b(?:expenditure|expenditures)\b.*?\.|.*?\b(?:expenditure|expenditures)\b.*?\.', re.IGNORECASE)
    income_pattern = re.compile(r'\b(?:income|incomes)\b.*?\.|.*?\b(?:income|incomes)\b.*?\.', re.IGNORECASE)

    assets = assets_pattern.findall(content)
    expenditures = expenditures_pattern.findall(content)
    incomes = income_pattern.findall(content)

    if not (assets or expenditures or incomes):
        print("No financial information found.")
        return {"message": "No financial information found"}

    try:
        for fact in assets:
            FinancialInfo.objects.create(transcript_id=transcript_id, category='Assets', fact=fact.strip())
        for fact in expenditures:
            FinancialInfo.objects.create(transcript_id=transcript_id, category='Expenditures', fact=fact.strip())
        for fact in incomes:
            FinancialInfo.objects.create(transcript_id=transcript_id, category='Income', fact=fact.strip())
    except Exception as e:
        print(f"Error saving financial information: {e}")
        return {"error": "Error saving financial information"}

    return {"message": "Financial information extracted and saved successfully"}
