import os
from typing import Sequence
from langchain.output_parsers import PydanticOutputParser
from langchain_core.prompts import PromptTemplate
from langchain_core.pydantic_v1 import BaseModel, Field
from langchain_openai import ChatOpenAI # type: ignore
from .models import FinancialInfo


class TranscriptExtract(BaseModel):
    assets: Sequence[str] = Field(description="Assets extracted from the transcript")
    expenditures: Sequence[str] = Field(description="Expenditures extracted from the transcript")
    income: Sequence[str] = Field(description="Income extracted from the transcript")

parser = PydanticOutputParser(pydantic_object=TranscriptExtract)

prompt = PromptTemplate(
    template="""Your task is to extract assets, expenditures, and income from a transcript between a Financial Adviser and their client.
             Example of a string to be extracted: "Martin is a partner in a law firm in London, earning an average of £15,000 per month before taxes."
             {format_instructions}
             {transcript}""",
    input_variables=["transcript"],
    partial_variables={"format_instructions": parser.get_format_instructions()},
)

model = ChatOpenAI(
    max_tokens=4096,
    temperature=0,
    model="gpt-3.5-turbo",
    api_key=os.getenv('OPENAI_API_KEY'),
)

chain = prompt | model | parser

def process_transcript(file_path, transcript_id):
    try:
        with open(file_path, 'r') as file:
            content = file.read()
    except Exception as e:
        print(f"Error reading file: {e}")
        return {"error": "Error reading file"}

    if not content.strip():
        return {"message": "File content is empty"}

    try:
        res = chain.invoke({"transcript": content})
        print(res, "line number 48")
        assets = res.assets
        expenditures = res.expenditures
        income = res.income
    except Exception as e:
        print(f"Error processing transcript with AI model: {e}")
        return {"error": "Error processing transcript"}

    try:
        for fact in assets:
            FinancialInfo.objects.create(transcript_id=transcript_id, category='Assets', fact=fact.strip())
        for fact in expenditures:
            FinancialInfo.objects.create(transcript_id=transcript_id, category='Expenditures', fact=fact.strip())
        for fact in income:
            FinancialInfo.objects.create(transcript_id=transcript_id, category='Income', fact=fact.strip())
    except Exception as e:
        print(f"Error saving financial information: {e}")
        return {"error": "Error saving financial information"}

    return {"message": "Financial information extracted and saved successfully"}
