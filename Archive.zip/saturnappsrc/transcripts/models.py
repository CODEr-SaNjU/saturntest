from django.db import models

class Transcript(models.Model):
    file = models.FileField(upload_to='transcripts/')
    uploaded_at = models.DateTimeField(auto_now_add=True)


class FinancialInfo(models.Model):
    transcript = models.ForeignKey(Transcript, related_name='financial_infos', on_delete=models.CASCADE)
    category = models.CharField(max_length=20)
    fact = models.TextField()

    def __str__(self):
        return f"{self.category}: {self.fact}"
