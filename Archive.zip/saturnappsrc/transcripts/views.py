from rest_framework.parsers import MultiPartParser, FormParser
from rest_framework.views import APIView
from rest_framework.response import Response
from .serializers import FinancialInfoSerializer, TranscriptSerializer
from .models import FinancialInfo
from .utils import process_transcript

class TranscriptUploadView(APIView):
    parser_classes = (MultiPartParser, FormParser)

    def post(self, request, *args, **kwargs):
        serializer = TranscriptSerializer(data=request.data)
        if serializer.is_valid():
            transcript = serializer.save()
            process_transcript(transcript.file.path, transcript.id)
            return Response({
                "message": "File uploaded successfully",
                "data": serializer.data
            }, status=201)
        return Response({
            "message": "Invalid input",
            "errors": serializer.errors
        }, status=400)


class FinancialInfoListView(APIView):
    def get(self, request, *args, **kwargs):
        financial_info = FinancialInfo.objects.all()
        serializer = FinancialInfoSerializer(financial_info, many=True)
        return Response(serializer.data)
